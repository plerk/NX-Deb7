package App::gnome_panel_monitor;

use strict;
use warnings;
use v5.10;
use Proc::ProcessTable;
use Number::Bytes::Human qw( format_bytes parse_bytes );

# ABSTRACT: Kill gnome-panel if it starts using too much memory
our $VERSION = '0.01'; # VERSION


sub main
{
  my $class = shift;
  my @ARGV = @_;
  
  foreach my $proc (@{ Proc::ProcessTable->new->table }) {
  
    next if $proc->uid != $<;
    next unless $proc->fname eq 'gnome-panel';
  
    say $proc->pid, ' ', format_bytes($proc->rss);
    if($proc->rss > parse_bytes('256M'))
    {
      say "KILLING";
      kill 15, $proc->pid;
      sleep 5;
      kill 9, $proc->pid;
    }
  }
}

1;

__END__

=pod

=head1 NAME

App::gnome_panel_monitor - Kill gnome-panel if it starts using too much memory

=head1 VERSION

version 0.01

=head1 SYNOPSIS

 % gnome_panel_monitor

=head1 DESCRIPTION

C<gnome-panel> consumes all the memory on my 24GB system sometimes making it
completely unresponsive until I kill it.  It seems to restart automatically
after being killed and I don't really want to follow up with the upstream
developers so I wrote this cron job to kill gnome-panel if it's memory
exceeds something reasonable.

There are probably better ways to do this, with C<ulimit> or some such, but
I don't really want to tinker with the B<gnome> or B<gnome-panel> configuration
or figure out where it starts, so I am going to brute force fix this.

Thank you for your cooperation.

=head1 AUTHOR

Graham Ollis <plicease@cpan.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by Graham Ollis.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
